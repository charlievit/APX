// ============================================================
// APX Character Sheet — Ancestry & Genetics Wizard
// Also reused by GM Tools to build Race Templates: same wizard, same
// window.state.ancestry it always wrote to, but Finish either applies it
// to the current character (ancTarget 'player') or saves/exports it as a
// standalone race template (ancTarget 'gmRace') instead of touching any
// character's baseStats.
// ============================================================
        let currentAncestryStep = 1;
        let ancTarget = 'player'; // 'player' or 'gmRace'
        window.ancTarget = ancTarget; // mirrored on window so other files (skill/perk pickers) can check which context is active
        let ancRaceEditId = null; // which window.gmRaces entry, when ancTarget === 'gmRace'
        window.gmRaces = window.gmRaces || [];
        let envResistPickerCallback = null;

        window.openEnvResistPicker = function(callback) {
            envResistPickerCallback = callback;
            let rows = NPC_ENERGY_TYPES.map(type => {
                let existingIdx = window.state.ancestryEnvResistances.findIndex(e => e.type === type);
                if (existingIdx === -1) {
                    return `<button onclick="window.selectEnvResistType('${type}')" class="w-full text-left text-xs px-2 py-1.5 rounded border bg-slate-900 text-slate-200 border-slate-700 hover:border-blue-500">${type} <span class="text-slate-500">(gain ER 5)</span></button>`;
                }
                let entry = window.state.ancestryEnvResistances[existingIdx];
                if (entry.immune) {
                    return `<button disabled class="w-full text-left text-xs px-2 py-1.5 rounded border bg-slate-800 text-slate-600 border-slate-800 cursor-not-allowed">${type} -- already Immune</button>`;
                }
                return `<button onclick="window.selectEnvResistType('${type}')" class="w-full text-left text-xs px-2 py-1.5 rounded border bg-emerald-900/30 text-emerald-300 border-emerald-700/50 hover:border-emerald-500">${type} <span class="text-slate-400">(ER 5 -- choose again for Immunity)</span></button>`;
            }).join('');
            let playerChoiceRow = window.ancTarget === 'gmRace'
                ? `<button onclick="window.selectEnvResistType(null)" class="w-full text-left text-xs px-2 py-1.5 rounded border bg-indigo-900/30 text-indigo-300 border-indigo-700/50 hover:border-indigo-400 mb-1 font-bold">Player's Choice -- let the player pick when they take this race</button>`
                : '';
            document.getElementById('envResistPickerBody').innerHTML = playerChoiceRow + rows;
            window.openModal('envResistPickerModal');
        };
        window.selectEnvResistType = function(type) {
            if (type === null) {
                window.closeModal('envResistPickerModal');
                let cb = envResistPickerCallback;
                envResistPickerCallback = null;
                if (cb) cb({ playerChoice: true });
                return;
            }
            let existingIdx = window.state.ancestryEnvResistances.findIndex(e => e.type === type);
            if (existingIdx === -1) {
                window.state.ancestryEnvResistances.push({ type, immune: false });
            } else {
                window.state.ancestryEnvResistances[existingIdx].immune = true;
                window.state.ancestryEnvResistances.push({ upgradesIndex: existingIdx });
            }
            window.closeModal('envResistPickerModal');
            window.recalculateMath();
            let cb = envResistPickerCallback;
            envResistPickerCallback = null;
            if (cb) cb();
        };

        // Environmental Vulnerability -- the flaw counterpart to
        // Environmental Resistance, same picker shape but simpler: each
        // purchase just names a new energy type at a fixed +5 damage, no
        // immunity-upgrade concept, so re-picking an already-vulnerable
        // type is simply disabled rather than offering an "upgrade".
        let envVulnPickerCallback = null;
        window.openEnvVulnPicker = function(callback) {
            envVulnPickerCallback = callback;
            let rows = NPC_ENERGY_TYPES.map(type => {
                let already = window.state.ancestryEnvVulnerabilities.some(e => e.type === type);
                if (already) {
                    return `<button disabled class="w-full text-left text-xs px-2 py-1.5 rounded border bg-slate-800 text-slate-600 border-slate-800 cursor-not-allowed">${type} -- already vulnerable</button>`;
                }
                return `<button onclick="window.selectEnvVulnType('${type}')" class="w-full text-left text-xs px-2 py-1.5 rounded border bg-slate-900 text-slate-200 border-slate-700 hover:border-red-500">${type} <span class="text-slate-500">(+5 damage taken)</span></button>`;
            }).join('');
            let playerChoiceRow = window.ancTarget === 'gmRace'
                ? `<button onclick="window.selectEnvVulnType(null)" class="w-full text-left text-xs px-2 py-1.5 rounded border bg-indigo-900/30 text-indigo-300 border-indigo-700/50 hover:border-indigo-400 mb-1 font-bold">Player's Choice -- let the player pick when they take this race</button>`
                : '';
            document.getElementById('envVulnPickerBody').innerHTML = playerChoiceRow + rows;
            window.openModal('envVulnPickerModal');
        };
        window.selectEnvVulnType = function(type) {
            if (type === null) {
                window.closeModal('envVulnPickerModal');
                let cb = envVulnPickerCallback;
                envVulnPickerCallback = null;
                if (cb) cb({ playerChoice: true });
                return;
            }
            window.state.ancestryEnvVulnerabilities.push({ type });
            window.closeModal('envVulnPickerModal');
            window.recalculateMath();
            let cb = envVulnPickerCallback;
            envVulnPickerCallback = null;
            if (cb) cb();
        };

        window.navWizard = function(dir) {
            window.jumpToAncStep(currentAncestryStep + dir);
        }

        window.jumpToAncStep = function(n) {
            let maxStep = ancTarget === 'gmRace' ? 3 : 4;
            if (n < 1 || n > maxStep) return;
            document.getElementById(`ancStep${currentAncestryStep}`).classList.remove('active');
            currentAncestryStep = n;
            document.getElementById(`ancStep${currentAncestryStep}`).classList.add('active');
            if (n === 4) renderAncFinalTraining();

            document.getElementById('wizBtnPrev').style.display = currentAncestryStep > 1 ? 'block' : 'none';
            document.getElementById('wizBtnNext').style.display = currentAncestryStep < maxStep ? 'block' : 'none';
            document.getElementById('wizBtnFinish').style.display = 'block';
            window.updateWizardTabs('ancTab', currentAncestryStep, maxStep);
        }

        window.syncAncestryWizard = function() {
            ancTarget = 'player';
            window.ancTarget = ancTarget;
            ancRaceEditId = null;
            document.getElementById('ancestryWizardTitle').innerText = 'Ancestry & Genetics Builder';
            document.getElementById('wizBtnFinish').innerText = 'Save & Apply';
            ATTRIBUTES.forEach(a => {
                document.getElementById(`wizBase_${a}`).value = window.state.baseStats[a] || 5;
                document.getElementById(`wizMod_${a}`).value = window.state.ancestry.bonuses[a] || 0;
            });
            document.getElementById('wizSize').value = window.state.ancestry.size;
            document.getElementById('wizSpeed').value = window.state.ancestry.speed;
            
            let lsOpts = document.getElementById('wizLife').options;
            for(let i=0; i<lsOpts.length; i++) {
                if(lsOpts[i].text === window.state.ancestry.lifespan) { document.getElementById('wizLife').selectedIndex = i; break; }
            }
            document.getElementById('wizName').value = window.state.ancestry.name;
            window.buildAncestryLists();
            window.jumpToAncStep(1);
            if (typeof window.renderImportedRaceList === 'function') window.renderImportedRaceList();
        }

        // Keeps each attribute's Base (Point Buy/Standard Array, 2-10) and
        // ancestry Mod (-2 to +2) from ever combining into a final score
        // below 2 or above 10, per Ch.2/Ch.3 rules. Runs before GP is
        // totaled so a clamp always reflects in what's displayed/saved.
        function clampAncestryAttrInputs() {
            ATTRIBUTES.forEach(a => {
                let baseEl = document.getElementById(`wizBase_${a}`);
                let modEl = document.getElementById(`wizMod_${a}`);
                if (!baseEl || !modEl) return;

                let base = parseInt(baseEl.value) || 5;
                if (base < 2) base = 2;
                if (base > 10) base = 10;
                baseEl.value = base;

                let mod = parseInt(modEl.value) || 0;
                if (mod > 2) mod = 2;
                if (mod < -2) mod = -2;
                if (base + mod > 10) mod = 10 - base;
                if (base + mod < 2) mod = 2 - base;
                modEl.value = mod;
            });

            let speedEl = document.getElementById('wizSpeed');
            if (speedEl) {
                let speed = parseInt(speedEl.value);
                if (isNaN(speed)) speed = 3;
                if (speed < 0) speed = 0;
                if (speed > 6) speed = 6;
                speedEl.value = speed;
            }
        }

        function traitCount(id) { return window.state.ancestry.traits.filter(x => x === id).length; }
        function flawCount(id) { return window.state.ancestry.flaws.filter(x => x === id).length; }

        // Flaws only ever refund up to 5 GP total (Ch.3), so once the raw
        // sum of already-selected flaws reaches that, one more flaw would
        // apply its full mechanical drawback for zero additional benefit.
        function currentFlawRefundRaw() {
            let sum = 0;
            window.state.ancestry.flaws.forEach(fId => {
                let fDef = ANCESTRY_FLAWS.find(x => x.id === fId);
                if (fDef) sum += Math.abs(fDef.cost);
            });
            return sum;
        }

        function renderAncEntry(def, count, isFlaw) {
            let costLabel = isFlaw ? `Refunds ${Math.abs(def.cost)} GP each` : `${def.cost} GP each`;
            if (def.rep) {
                let atMax = def.max ? count >= def.max : false;
                let grantedSkillsNote = (def.id === 't_skap' && window.state.ancestrySkillAptitudeSkills.length)
                    ? `<div class="text-[9px] text-emerald-400 mt-0.5">Trained: ${window.state.ancestrySkillAptitudeSkills.map(id => {
                        let custom = window.state.customSkills.find(s => s.id === id);
                        return custom ? custom.name : id;
                    }).join(', ')}</div>` : '';
                return `
                    <div class="flex items-center justify-between gap-2 p-1.5 rounded border border-transparent hover:border-slate-700 hover:bg-slate-800 transition">
                        <div class="flex-1">
                            <div class="text-[10px] font-bold text-slate-300 leading-tight">${def.name} <span class="${isFlaw ? 'text-red-500' : 'text-emerald-500'}">[${costLabel}${def.max ? `, max ${def.max}` : ''}]</span></div>
                            <div class="text-[9px] text-slate-500 leading-tight">${def.desc}</div>
                            ${grantedSkillsNote}
                        </div>
                        <div class="flex items-center gap-1 shrink-0">
                            <button onclick="window.setAncCount('${isFlaw ? 'flaw' : 'trait'}', '${def.id}', -1)" ${count<=0?'disabled':''} class="w-5 h-5 rounded ${count<=0?'bg-slate-800 text-slate-600':'bg-slate-700 hover:bg-slate-600 text-white'} text-xs font-bold">-</button>
                            <span class="w-5 text-center text-xs font-bold text-white">${count}</span>
                            <button onclick="window.setAncCount('${isFlaw ? 'flaw' : 'trait'}', '${def.id}', 1)" ${atMax?'disabled':''} class="w-5 h-5 rounded ${atMax?'bg-slate-800 text-slate-600':'bg-amber-700 hover:bg-amber-600 text-white'} text-xs font-bold">+</button>
                        </div>
                    </div>
                `;
            }
            let isChecked = count > 0 ? 'checked' : '';
            return `<label class="flex items-start gap-2 p-1.5 hover:bg-slate-800 rounded cursor-pointer transition border border-transparent hover:border-slate-700">
                <input type="checkbox" class="mt-0.5" value="${def.id}" ${isChecked} onchange="window.toggleAnc('${isFlaw ? 'flaw' : 'trait'}', '${def.id}', this.checked)">
                <div><div class="text-[10px] font-bold text-slate-300 leading-tight">${def.name} <span class="${isFlaw ? 'text-red-500' : 'text-emerald-500'}">[${costLabel.replace(' each','')}]</span></div><div class="text-[9px] text-slate-500 leading-tight">${def.desc}</div></div>
            </label>`;
        }

        window.buildAncestryLists = function() {
            document.getElementById('wizTraitsList').innerHTML = ANCESTRY_TRAITS.map(t => renderAncEntry(t, traitCount(t.id), false)).join('');
            document.getElementById('wizFlawsList').innerHTML = ANCESTRY_FLAWS.map(f => renderAncEntry(f, flawCount(f.id), true)).join('');
            window.calcAncestryGp();
        }

        // Non-repeatable traits/flaws: plain checkbox on/off.
        window.toggleAnc = function(type, id, isChecked) {
            if(type === 'trait') {
                if(isChecked) {
                    window.state.ancestry.traits.push(id);
                    if(id === 't_innwpn') addAncestryInnateWeapon();
                } else {
                    window.state.ancestry.traits = window.state.ancestry.traits.filter(x => x !== id);
                    if(id === 't_innwpn') removeAncestryInnateWeapon();
                }
            } else {
                if(isChecked) {
                    if (currentFlawRefundRaw() >= 5) {
                        window.showConfirm("Flaws only refund up to 5 GP total. You already have enough selected -- taking another would apply its drawback for no further benefit.", null, true);
                        window.buildAncestryLists(); // resets the checkbox back to unchecked
                        return;
                    }
                    window.state.ancestry.flaws.push(id);
                }
                else window.state.ancestry.flaws = window.state.ancestry.flaws.filter(x => x !== id);
            }
            window.buildAncestryLists();
        }

        function addAncestryInnateWeapon() {
            if (!window.state.weapons.some(w => w.isAncestry)) {
                window.state.weapons.push({ name: "Ancestry: Innate Weapon", attr: "STR", tr: true, dmg: "1d6", ap: 2, isAncestry: true });
                window.recalculateMath();
            }
        }
        function removeAncestryInnateWeapon() {
            window.state.weapons = window.state.weapons.filter(w => !w.isAncestry);
            window.recalculateMath();
        }

        // Repeatable traits/flaws: +/- stepper. Handles the two special
        // cases that need more than "just push/pop an id" -- Bonus Perk
        // (opens a picker; only recorded once a perk, and choice if
        // needed, is actually confirmed) and Fragile (blocked once Max HP
        // would drop to 5 or less).
        window.setAncCount = function(type, id, delta) {
            let isFlaw = type === 'flaw';
            let def = isFlaw ? ANCESTRY_FLAWS.find(x => x.id === id) : ANCESTRY_TRAITS.find(x => x.id === id);
            if (!def) return;
            let arr = isFlaw ? window.state.ancestry.flaws : window.state.ancestry.traits;
            let count = arr.filter(x => x === id).length;

            if (delta > 0) {
                if (def.max && count >= def.max) return;

                if (isFlaw && currentFlawRefundRaw() >= 5) {
                    window.showConfirm("Flaws only refund up to 5 GP total. You already have enough selected -- taking another would apply its drawback for no further benefit.", null, true);
                    return;
                }

                if (id === 't_bp') {
                    window.openAncBonusPerkModal();
                    return; // 't_bp' is only pushed once a perk (+choice) is actually confirmed
                }
                if (id === 't_skap') {
                    window.openSkillTrainPicker((skillId) => {
                        arr.push(id);
                        window.state.ancestrySkillAptitudeSkills.push(skillId);
                        window.buildAncestryLists();
                    }, 'Choose a Skill to Train (Skill Aptitude)', 'Ancestry (Skill Aptitude)');
                    return; // only pushed once a skill is actually chosen, same idea as 't_bp' above
                }
                if (id === 't_env') {
                    window.openEnvResistPicker((sentinel) => {
                        arr.push(id);
                        // Real type selections already push their own
                        // entry inside selectEnvResistType; a Player's
                        // Choice sentinel arrives here instead and needs
                        // pushing explicitly so the array stays in sync
                        // with arr's purchase count.
                        if (sentinel) window.state.ancestryEnvResistances.push(sentinel);
                        window.buildAncestryLists();
                    });
                    return; // only pushed once a type (or immunity upgrade) is actually chosen
                }
                if (id === 'f_env') {
                    window.openEnvVulnPicker((sentinel) => {
                        arr.push(id);
                        if (sentinel) window.state.ancestryEnvVulnerabilities.push(sentinel);
                        window.buildAncestryLists();
                    });
                    return; // only pushed once a type is actually chosen
                }
                if (id === 'f_frag') {
                    let con = parseInt(document.getElementById('wizBase_CON').value) || 5;
                    if ((5 * con) - (5 * (count + 1)) <= 5) {
                        window.showConfirm("Your Maximum HP would drop to 5 or less. You cannot take Fragile again.", null, true);
                        return;
                    }
                }

                arr.push(id);
                if (id === 't_innwpn' && count === 0) addAncestryInnateWeapon();
            } else {
                if (count <= 0) return;
                // A GM-provided race's traits/flaws are locked in for the
                // player -- they can add more of their own on top (a
                // player might independently also pick Skill Aptitude),
                // but can't strip out what the GM specifically granted.
                // Attribute mods, size, speed, and lifespan are NOT
                // covered by this and stay fully player-adjustable.
                let baselineKey = isFlaw ? 'flaw:' + id : id;
                let baseline = (window.state.ancestry.gmBaselineCounts || {})[baselineKey] || 0;
                if (count <= baseline) {
                    window.showConfirm(`This ${isFlaw ? 'flaw' : 'trait'} was granted by your species and can't be removed. You can still adjust your ancestry's attribute bonuses, size, speed, and lifespan freely.`, null, true);
                    return;
                }
                if (id === 't_bp') {
                    window.state.ancestryBonusPerks.pop();
                }
                if (id === 't_skap') {
                    let skillId = window.state.ancestrySkillAptitudeSkills.pop();
                    if (skillId) window.state.skillsTrained[skillId] = false;
                }
                if (id === 't_env') {
                    let last = window.state.ancestryEnvResistances.pop();
                    if (last && last.upgradesIndex !== undefined) {
                        let target = window.state.ancestryEnvResistances[last.upgradesIndex];
                        if (target) target.immune = false;
                    }
                }
                if (id === 'f_env') {
                    window.state.ancestryEnvVulnerabilities.pop();
                }
                let idx = arr.lastIndexOf(id);
                if (idx >= 0) arr.splice(idx, 1);
                if (id === 't_innwpn' && count - 1 === 0) removeAncestryInnateWeapon();
            }
            window.buildAncestryLists();
        }

        window.openAncBonusPerkModal = function() {
            let alreadyChosen = window.state.ancestryBonusPerks.map(bp => bp.perkId);
            let genPerks = PERKS_DB.filter(p => p.attr === 'GEN').filter(p => {
                let timesChosen = alreadyChosen.filter(id => id === p.id).length;
                if (timesChosen === 0) return true;
                return p.max > timesChosen; // only offer again if it can still be taken further
            });
            let playerChoiceHtml = window.ancTarget === 'gmRace'
                ? `<div class="p-2 bg-indigo-900/30 hover:bg-indigo-900/50 rounded border border-indigo-700/50 cursor-pointer transition mb-2" onclick="window.selectAncBonusPerk(null)">
                    <div class="font-bold text-indigo-300 text-sm">Player's Choice</div>
                    <div class="text-[10px] text-slate-400 leading-tight">Let the player pick when they take this race</div>
                   </div>`
                : '';
            let html = genPerks.map(p => `
                <div class="p-2 bg-slate-800 hover:bg-slate-700 rounded border border-slate-600 cursor-pointer transition" onclick="window.selectAncBonusPerk('${p.id}')">
                    <div class="font-bold text-slate-200 text-sm">${p.name}</div>
                    <div class="text-[10px] text-slate-400 leading-tight">${p.baseDesc}</div>
                </div>
            `).join('');
            document.getElementById('ancBonusPerkList').innerHTML = playerChoiceHtml + html;
            window.openModal('ancBonusPerkModal');
        }

        window.selectAncBonusPerk = function(id) {
            if (id === null) {
                window.closeModal('ancBonusPerkModal');
                window.state.ancestry.traits.push('t_bp');
                window.state.ancestryBonusPerks.push({ playerChoice: true });
                window.recalculateMath();
                window.buildAncestryLists();
                return;
            }
            let p = PERKS_DB.find(x => x.id === id);
            let dynamicChoices = window.getDynamicChoicesFor(p);

            if (id === 'gen_latentpot' && dynamicChoices.length === 0) {
                window.showConfirm("No Core Attributes are below 4. You cannot select this perk.", null, true);
                return; // leave the Bonus Perk list open so they can pick something else
            }

            window.closeModal('ancBonusPerkModal');

            let commit = (choice) => {
                window.state.ancestry.traits.push('t_bp');
                window.state.ancestryBonusPerks.push({ perkId: id, choice: choice || null });
                window.recalculateMath();
                window.buildAncestryLists();
            };

            if (dynamicChoices && dynamicChoices.length > 0) {
                window.openPerkChoicePicker(p, 'Ancestry Bonus', dynamicChoices, commit);
                return;
            }

            commit(null);
        }

        window.cancelAncBonusPerk = function() {
            // Nothing is tentatively recorded until a perk (and choice, if
            // any) is actually confirmed, so cancelling just closes it.
            window.closeModal('ancBonusPerkModal');
        }

        window.calcAncestryGp = function() {
            clampAncestryAttrInputs();

            let gp = 0;
            let limit = parseInt(document.getElementById('wizGpLimit').value) || 15;
            // dispGpLimit lives in the main character sheet's header (next
            // to the Ancestry button), not inside this modal -- it doesn't
            // exist when this wizard is reused standalone in GM Tools.
            let dispLimitEl = document.getElementById('dispGpLimit');
            if (dispLimitEl) dispLimitEl.innerText = limit;

            ATTRIBUTES.forEach(a => {
                let mod = parseInt(document.getElementById(`wizMod_${a}`).value) || 0;
                if(mod > 0) gp += mod;
                if(mod < 0) gp += mod; 
            });
            
            gp += parseInt(document.getElementById('wizLife').value) || 0;
            
            let size = parseInt(document.getElementById('wizSize').value) || 30;
            if(size !== 30) gp += 1;
            
            let speed = parseInt(document.getElementById('wizSpeed').value) || 3;
            gp += (speed - 3);

            let flawRefund = 0;
            window.state.ancestry.flaws.forEach(fId => {
                let fDef = ANCESTRY_FLAWS.find(x => x.id === fId);
                if(fDef) flawRefund += Math.abs(fDef.cost);
            });
            if(flawRefund > 5) flawRefund = 5;
            gp -= flawRefund;

            window.state.ancestry.traits.forEach(tId => {
                let tDef = ANCESTRY_TRAITS.find(x => x.id === tId);
                if(tDef) gp += tDef.cost;
            });

            document.getElementById('wizGpUsed').innerText = gp;
            let errEl = document.getElementById('wizError');
            if(gp > limit) {
                errEl.style.display = 'block';
                document.getElementById('wizBtnFinish').disabled = true;
                document.getElementById('wizBtnFinish').classList.add('opacity-50', 'cursor-not-allowed');
            } else {
                errEl.style.display = 'none';
                document.getElementById('wizBtnFinish').disabled = false;
                document.getElementById('wizBtnFinish').classList.remove('opacity-50', 'cursor-not-allowed');
            }
            window.state.ancestry.gpUsed = gp;

            // Advisory only, never blocking: Point Buy and Standard Array
            // both redistribute points from a baseline of 5 per Core
            // Attribute (35 total across all 7), so the modifiers should
            // sum to 0. This varies table to table (some GMs deliberately
            // run stronger/weaker campaigns), so this is just a heads-up.
            let baseTotal = ATTRIBUTES.reduce((sum, a) => sum + (parseInt(document.getElementById(`wizBase_${a}`).value) || 0), 0);
            let baseNote = document.getElementById('wizBaseStatNote');
            if (baseNote) {
                let diff = baseTotal - 35;
                if (diff === 0) {
                    baseNote.classList.add('hidden');
                } else {
                    baseNote.classList.remove('hidden');
                    baseNote.innerText = `Base attributes total ${baseTotal} (${diff > 0 ? '+' : ''}${diff} vs. the standard 35 for Point Buy/Standard Array). This may be intentional for your table.`;
                }
            }
        }

        // ---- Step 4: Final Training (4 + INT mod skills, 2 Saving Throws) ----
        function ancFinalSkillLimit() {
            let base = parseInt(document.getElementById('wizBase_INT').value) || 5;
            let mod = parseInt(document.getElementById('wizMod_INT').value) || 0;
            let intMod = (base + mod) - 5;
            return Math.max(0, 4 + intMod);
        }
        function ancSkillDisplayName(id) {
            let custom = window.state.customSkills.find(s => s.id === id);
            if (custom) return custom.name;
            let s = SKILLS.find(x => x.id === id);
            return s ? s.name : id;
        }
        function renderAncFinalTraining() {
            let limit = ancFinalSkillLimit();
            let ft = window.state.ancestryFinalTraining;
            document.getElementById('ancFinalSkillCount').innerText = limit;
            document.getElementById('ancFinalSkillProgress').innerText = `${ft.skills.length}/${limit}`;
            document.getElementById('ancFinalSkillList').innerHTML = ft.skills.length ? ft.skills.map((id, idx) => `
                <div class="flex items-center justify-between bg-slate-800 border border-slate-700 rounded px-2 py-1">
                    <span class="text-xs text-slate-200">${ancSkillDisplayName(id)}</span>
                    <button onclick="window.ancRemoveFinalSkill(${idx})" class="text-red-500 hover:text-red-400 font-bold text-xs">&times;</button>
                </div>
            `).join('') : '<div class="text-[10px] text-slate-600">None chosen yet</div>';
            let addBtn = document.getElementById('ancAddFinalSkillBtn');
            addBtn.disabled = ft.skills.length >= limit;
            addBtn.classList.toggle('opacity-50', ft.skills.length >= limit);

            document.getElementById('ancFinalSaveProgress').innerText = `${ft.saves.length}/2`;
            document.getElementById('ancFinalSaveGrid').innerHTML = ATTRIBUTES.map(a => {
                let checked = ft.saves.includes(a);
                let disabled = !checked && ft.saves.length >= 2;
                return `<label class="flex items-center gap-1 text-xs text-slate-300 ${disabled ? 'opacity-40' : ''}">
                    <input type="checkbox" ${checked ? 'checked' : ''} ${disabled ? 'disabled' : ''} onchange="window.ancToggleFinalSave('${a}', this.checked)"> ${a}
                </label>`;
            }).join('');
        }
        window.ancAddFinalSkill = function() {
            let ft = window.state.ancestryFinalTraining;
            if (ft.skills.length >= ancFinalSkillLimit()) return;
            window.openSkillTrainPicker((skillId) => {
                ft.skills.push(skillId);
                renderAncFinalTraining();
            }, 'Choose a Skill to Train (Ancestry Training)', 'Ancestry (Final Training)');
        };
        window.ancRemoveFinalSkill = function(idx) {
            let ft = window.state.ancestryFinalTraining;
            let skillId = ft.skills[idx];
            window.state.skillsTrained[skillId] = false;
            ft.skills.splice(idx, 1);
            renderAncFinalTraining();
            window.recalculateMath();
        };
        window.ancToggleFinalSave = function(attr, checked) {
            let ft = window.state.ancestryFinalTraining;
            if (checked) {
                if (ft.saves.length >= 2) return;
                ft.saves.push(attr);
                window.state.savesTrained[attr] = true;
            } else {
                ft.saves = ft.saves.filter(a => a !== attr);
                window.state.savesTrained[attr] = false;
            }
            renderAncFinalTraining();
            window.recalculateMath();
        };

        window.finishAncestry = function() {
            let limit = parseInt(document.getElementById('wizGpLimit').value) || 15;
            if(window.state.ancestry.gpUsed > limit) return;
            window.state.ancestry.name = document.getElementById('wizName').value || "Unknown Species";
            window.state.ancestry.size = parseInt(document.getElementById('wizSize').value) || 30;
            window.state.ancestry.speed = parseInt(document.getElementById('wizSpeed').value) || 3;
            window.state.ancestry.lifespan = document.getElementById('wizLife').options[document.getElementById('wizLife').selectedIndex].text;

            ATTRIBUTES.forEach(a => {
                window.state.ancestry.bonuses[a] = parseInt(document.getElementById(`wizMod_${a}`).value) || 0;
            });

            if (ancTarget === 'gmRace') {
                // A race template only ever captures the ancestry itself
                // (mods/size/speed/lifespan/traits/flaws + its Bonus Perk
                // choices) -- never baseStats, which is a player's own
                // Point Buy/Standard Array allocation, not part of a race.
                let entry = {
                    id: ancRaceEditId || crypto.randomUUID(),
                    name: window.state.ancestry.name,
                    ancestry: JSON.parse(JSON.stringify(window.state.ancestry)),
                    ancestryBonusPerks: JSON.parse(JSON.stringify(window.state.ancestryBonusPerks)),
                    // Skill Aptitude and Environmental Resistance both need
                    // more than just the trait count in ancestry.traits --
                    // which specific skill was trained, which energy type
                    // was chosen -- so a race template has to carry these
                    // parallel arrays too, or a player importing it gets a
                    // trait that LOOKS purchased but never actually applied.
                    ancestrySkillAptitudeSkills: JSON.parse(JSON.stringify(window.state.ancestrySkillAptitudeSkills || [])),
                    ancestryEnvResistances: JSON.parse(JSON.stringify(window.state.ancestryEnvResistances || [])),
                    ancestryEnvVulnerabilities: JSON.parse(JSON.stringify(window.state.ancestryEnvVulnerabilities || []))
                };
                let existingIdx = window.gmRaces.findIndex(r => r.id === entry.id);
                if (existingIdx >= 0) window.gmRaces[existingIdx] = entry;
                else window.gmRaces.push(entry);

                window.closeModal('ancestryModal');
                if (typeof window.renderGmRaceList === 'function') window.renderGmRaceList();
                if (typeof window.openGmRaceRosterModal === 'function') {
                    window.openGmRaceRosterModal();
                    window.showConfirm(`${entry.name} is saved to your Race Templates. Use Export to save it to a file.`, null, true);
                }
                return;
            }

            // Player's own base attribute allocation -- irrelevant to (and
            // never overwritten by) a race template, since a species'
            // modifiers layer on top of whatever a player separately chose.
            ATTRIBUTES.forEach(a => {
                window.state.baseStats[a] = parseInt(document.getElementById(`wizBase_${a}`).value) || 5;
            });

            window.closeModal('ancestryModal');
            window.recalculateMath();
        }

        // ------------------------------------------------------------------
        // GM Race Templates: build, list, delete, export/import. Entirely
        // separate from any character's save data, same pattern as the GM
        // NPC roster -- window.gmRaces holds them, saved to their own file.
        // ------------------------------------------------------------------
        window.openGmRaceBuilder = function(raceId) {
            if (raceId) {
                let entry = window.gmRaces.find(r => r.id === raceId);
                if (!entry) return;
                ancRaceEditId = raceId;
                window.state.ancestry = JSON.parse(JSON.stringify(entry.ancestry));
                window.state.ancestryBonusPerks = JSON.parse(JSON.stringify(entry.ancestryBonusPerks || []));
            } else {
                ancRaceEditId = null;
                window.state.ancestry = JSON.parse(JSON.stringify(getInitialState().ancestry));
                window.state.ancestryBonusPerks = [];
            }
            window.openModal('ancestryModal'); // this calls syncAncestryWizard(), which resets ancTarget to 'player'
            ancTarget = 'gmRace'; // ...so it's set back to 'gmRace' immediately after
            window.ancTarget = ancTarget;
            document.getElementById('ancestryWizardTitle').innerText = 'Race Template Builder';
            document.getElementById('wizBtnFinish').innerText = 'Save Race Template';
        };

        window.openGmRaceRosterModal = function() {
            window.renderGmRaceList();
            window.openModal('gmRaceRosterModal');
        };

        window.renderGmRaceList = function() {
            let body = document.getElementById('gmRaceListBody');
            if (!body) return;
            if (!window.gmRaces.length) {
                body.innerHTML = '<div class="text-xs text-slate-500 text-center py-6">No race templates yet. Click "+ New Race" to build one.</div>';
                return;
            }
            body.innerHTML = window.gmRaces.map(entry => `
                <div class="flex items-center justify-between bg-slate-900 border border-slate-700 rounded p-2">
                    <div>
                        <div class="text-sm font-bold text-indigo-300">${entry.name || 'Unnamed Race'}</div>
                        <div class="text-[10px] text-slate-500">${entry.ancestry.gpUsed} / 15 GP spent${entry.ancestry.gpUsed < 15 ? ` -- ${15 - entry.ancestry.gpUsed} GP left for subrace customization` : ''}</div>
                    </div>
                    <div class="flex gap-1">
                        <button onclick="window.openGmRaceBuilder('${entry.id}')" class="text-[10px] text-indigo-400 hover:text-indigo-300 font-bold px-2 py-1">Edit</button>
                        <button onclick="window.exportGmRace('${entry.id}')" class="text-[10px] text-slate-400 hover:text-slate-300 font-bold px-2 py-1">Export</button>
                        <button onclick="window.deleteGmRace('${entry.id}')" class="text-[10px] text-red-400 hover:text-red-300 font-bold px-2 py-1">Delete</button>
                    </div>
                </div>
            `).join('');
        };

        window.deleteGmRace = function(id) {
            let entry = window.gmRaces.find(r => r.id === id);
            if (!entry) return;
            window.showConfirm(`Delete ${entry.name || 'this race'}? This cannot be undone.`, () => {
                window.gmRaces = window.gmRaces.filter(r => r.id !== id);
                window.renderGmRaceList();
            });
        };

        function ancDownloadJson(filename, data) {
            let dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data, null, 2));
            let anchor = document.createElement('a');
            anchor.setAttribute("href", dataStr);
            anchor.setAttribute("download", filename);
            document.body.appendChild(anchor);
            anchor.click();
            anchor.remove();
        }

        window.exportGmRace = function(id) {
            let entry = window.gmRaces.find(r => r.id === id);
            if (!entry) return;
            let fileName = (entry.name || 'race').replace(/[^a-z0-9]/gi, '_').toLowerCase();
            ancDownloadJson(fileName + ".json", entry);
        };

        window.exportAllGmRaces = function() {
            if (!window.gmRaces.length) {
                window.showConfirm("No race templates to export yet.", null, true);
                return;
            }
            ancDownloadJson("gm_race_templates.json", window.gmRaces);
        };

        window.importGmRace = function(event) {
            let files = Array.from(event.target.files || []);
            if (!files.length) return;
            let remaining = files.length;
            let hadError = false;
            files.forEach(file => {
                let reader = new FileReader();
                reader.onload = function(e) {
                    try {
                        let parsed = JSON.parse(e.target.result);
                        let entries = Array.isArray(parsed) ? parsed : [parsed];
                        entries.forEach(entry => {
                            if (!entry || !entry.ancestry) return; // not a recognizable race file, skip silently
                            entry.id = entry.id || crypto.randomUUID();
                            if (window.gmRaces.some(r => r.id === entry.id)) entry.id = crypto.randomUUID();
                            window.gmRaces.push(entry);
                        });
                    } catch (err) {
                        console.error("Failed to parse race file:", file.name, err);
                        hadError = true;
                    }
                    remaining--;
                    if (remaining === 0) {
                        if (typeof window.renderGmRaceList === 'function') window.renderGmRaceList();
                        if (typeof window.renderImportedRaceList === 'function') window.renderImportedRaceList();
                        event.target.value = '';
                        if (hadError) window.showConfirm("One or more selected files weren't valid race files and were skipped.", null, true);
                    }
                };
                reader.readAsText(file);
            });
        };

// Player-side: shows whatever GM race templates have been imported as a
// "choose a starting race" list in Step 1. Only exists on the main
// character sheet (GM Tools has no such UI, so this quietly no-ops there
// via the element-existence check).
window.renderImportedRaceList = function() {
    let wrap = document.getElementById('importedRaceListWrap');
    let list = document.getElementById('importedRaceList');
    if (!wrap || !list) return;
    if (!window.gmRaces.length) {
        wrap.classList.add('hidden');
        return;
    }
    wrap.classList.remove('hidden');
    list.innerHTML = window.gmRaces.map(entry => `
        <button onclick="window.selectGmRace('${entry.id}')" class="text-left p-2 bg-slate-900 border border-slate-700 hover:border-indigo-500 rounded transition">
            <div class="text-xs font-bold text-indigo-300">${entry.name || 'Unnamed Race'}</div>
            <div class="text-[9px] text-slate-500">${entry.ancestry.gpUsed} / 15 GP spent${entry.ancestry.gpUsed < 15 ? ` (${15 - entry.ancestry.gpUsed} left for you to customize)` : ''}</div>
        </button>
    `).join('');
};

// Loads a GM race template as this character's starting ancestry. Never
// touches baseStats -- a species' modifiers layer on top of whatever
// Point Buy/Standard Array allocation the player already has, which is a
// separate, personal choice.
window.selectGmRace = function(raceId) {
    let entry = window.gmRaces.find(r => r.id === raceId);
    if (!entry) return;

    // Selecting a (possibly different) race template replaces the
    // ancestry-granted Skill Aptitude training from whatever was there
    // before -- untrain those first so switching races doesn't leave
    // stale skills marked trained from a race the player no longer has.
    (window.state.ancestrySkillAptitudeSkills || []).forEach(skillId => {
        if (window.state.skillSource && window.state.skillSource[skillId] === 'Ancestry (Skill Aptitude)') {
            window.state.skillsTrained[skillId] = false;
            delete window.state.skillSource[skillId];
        }
    });

    window.state.ancestry = JSON.parse(JSON.stringify(entry.ancestry));
    // Snapshot of what the GM granted, per trait/flaw id, so the player
    // can freely ADD more of their own choosing on top, but can't remove
    // what the GM specifically gave them. Attribute mods/size/speed/
    // lifespan aren't tracked here at all -- those stay fully editable,
    // since a species' raw stat block is something a player is always
    // meant to be able to tune to their character.
    window.state.ancestry.gmBaselineCounts = {};
    window.state.ancestry.traits.forEach(id => {
        window.state.ancestry.gmBaselineCounts[id] = (window.state.ancestry.gmBaselineCounts[id] || 0) + 1;
    });
    window.state.ancestry.flaws.forEach(id => {
        window.state.ancestry.gmBaselineCounts['flaw:' + id] = (window.state.ancestry.gmBaselineCounts['flaw:' + id] || 0) + 1;
    });
    window.state.ancestryBonusPerks = JSON.parse(JSON.stringify(entry.ancestryBonusPerks || []));
    window.state.ancestrySkillAptitudeSkills = JSON.parse(JSON.stringify(entry.ancestrySkillAptitudeSkills || []));
    window.state.ancestryEnvResistances = JSON.parse(JSON.stringify(entry.ancestryEnvResistances || []));
    window.state.ancestryEnvVulnerabilities = JSON.parse(JSON.stringify(entry.ancestryEnvVulnerabilities || []));

    // Now actually apply what the GM chose -- the parallel arrays above
    // only record WHICH skill/energy type was picked; the character
    // sheet's own trained-skill state has to be updated to match, or the
    // skill just sits there un-trained despite the trait being present.
    // Entries that are still a "Player's Choice" sentinel (null, or
    // {playerChoice:true}) are skipped here -- they get resolved below,
    // through the sequential pop-up queue, instead.
    if (!window.state.skillSource) window.state.skillSource = {};
    window.state.ancestrySkillAptitudeSkills.forEach(skillId => {
        if (!skillId) return;
        window.state.skillsTrained[skillId] = true;
        window.state.skillSource[skillId] = 'Ancestry (Skill Aptitude)';
    });

    ATTRIBUTES.forEach(a => {
        document.getElementById(`wizMod_${a}`).value = window.state.ancestry.bonuses[a] || 0;
    });
    document.getElementById('wizSize').value = window.state.ancestry.size;
    document.getElementById('wizSpeed').value = window.state.ancestry.speed;
    let lsOpts = document.getElementById('wizLife').options;
    for (let i = 0; i < lsOpts.length; i++) {
        if (lsOpts[i].text === window.state.ancestry.lifespan) { document.getElementById('wizLife').selectedIndex = i; break; }
    }
    // Show the GM's chosen name verbatim, even if it happens to be
    // "Human" -- that's the blank-wizard DEFAULT's placeholder-hiding
    // behavior, not something that should apply to a name a GM
    // deliberately typed in when building this specific race template.
    document.getElementById('wizName').value = window.state.ancestry.name;
    window.buildAncestryLists();
    window.recalculateMath();

    // Queue up one pop-up per unresolved "Player's Choice" the GM left in
    // this race, then work through them one at a time.
    window.queuePendingRaceChoices();
};

// ----------------------------------------------------------------------
// Player's Choice resolution: a GM building a race template can leave
// Skill Aptitude, Environmental Resistance, or Bonus Perk as "the
// player's choice" instead of picking for them. On import, those show up
// as sentinels (null for a skill, {playerChoice:true} for the others) in
// the same parallel arrays real choices live in. This walks the arrays,
// finds every unresolved sentinel, and pops up the normal picker for
// each one in turn -- confirming one immediately opens the next, so a
// race with "Skill Aptitude x2 (Player's Choice)" gives the player two
// back-to-back skill pickers, the second one unable to re-select
// whatever the first one just trained.
// ----------------------------------------------------------------------
let pendingRaceChoiceQueue = [];
window.queuePendingRaceChoices = function() {
    pendingRaceChoiceQueue = [];
    (window.state.ancestrySkillAptitudeSkills || []).forEach((skillId, idx) => {
        if (!skillId) pendingRaceChoiceQueue.push({ type: 'skill', idx });
    });
    (window.state.ancestryEnvResistances || []).forEach((entry, idx) => {
        if (entry && entry.playerChoice) pendingRaceChoiceQueue.push({ type: 'envResist', idx });
    });
    (window.state.ancestryEnvVulnerabilities || []).forEach((entry, idx) => {
        if (entry && entry.playerChoice) pendingRaceChoiceQueue.push({ type: 'envVuln', idx });
    });
    (window.state.ancestryBonusPerks || []).forEach((entry, idx) => {
        if (entry && entry.playerChoice) pendingRaceChoiceQueue.push({ type: 'bonusPerk', idx });
    });
    window.processNextPendingRaceChoice();
};
window.processNextPendingRaceChoice = function() {
    if (!pendingRaceChoiceQueue.length) return;
    let next = pendingRaceChoiceQueue.shift();
    if (next.type === 'skill') {
        window.openSkillTrainPicker((skillId) => {
            window.state.ancestrySkillAptitudeSkills[next.idx] = skillId;
            window.state.skillsTrained[skillId] = true;
            if (!window.state.skillSource) window.state.skillSource = {};
            window.state.skillSource[skillId] = 'Ancestry (Skill Aptitude)';
            window.recalculateMath();
            window.processNextPendingRaceChoice();
        }, 'Your Species grants Skill Aptitude -- choose a Skill to Train', 'Ancestry (Skill Aptitude)');
    } else if (next.type === 'envResist') {
        window.openEnvResistPicker((sentinel) => {
            // selectEnvResistType already pushed a NEW entry onto the
            // array for a real type choice (or upgraded an existing one
            // to Immune) -- the placeholder sentinel this pending entry
            // occupied needs removing so it doesn't linger as a second,
            // bogus resistance.
            if (!sentinel) window.state.ancestryEnvResistances.splice(next.idx, 1);
            window.recalculateMath();
            window.processNextPendingRaceChoice();
        });
        // Re-point the picker at "first purchase" framing by temporarily
        // clearing this placeholder so it doesn't show up as an already-
        // taken type in the list the player is choosing from.
        window.state.ancestryEnvResistances[next.idx] = { __placeholder: true };
    } else if (next.type === 'envVuln') {
        window.openEnvVulnPicker((sentinel) => {
            if (!sentinel) window.state.ancestryEnvVulnerabilities.splice(next.idx, 1);
            window.recalculateMath();
            window.processNextPendingRaceChoice();
        });
        window.state.ancestryEnvVulnerabilities[next.idx] = { __placeholder: true };
    } else if (next.type === 'bonusPerk') {
        window.state.ancestryBonusPerks.splice(next.idx, 1); // remove the placeholder; selectAncBonusPerk pushes a fresh real entry
        window.openAncBonusPerkModal();
        // selectAncBonusPerk pushes both a 't_bp' trait entry AND the
        // chosen perk's own ancestryBonusPerks entry -- but the trait
        // count here was already established by the GM's original
        // Player's Choice purchase, so this wrapper has to pop the
        // trait-count side back off (once) to avoid double-counting,
        // while keeping the real perk choice that gets pushed alongside it.
        let origSelect = window.selectAncBonusPerk;
        window.selectAncBonusPerk = function(id) {
            window.selectAncBonusPerk = origSelect;
            let traitCountBefore = window.state.ancestry.traits.filter(t => t === 't_bp').length;
            origSelect(id);
            let traitCountAfter = window.state.ancestry.traits.filter(t => t === 't_bp').length;
            if (traitCountAfter > traitCountBefore) {
                window.state.ancestry.traits.splice(window.state.ancestry.traits.lastIndexOf('t_bp'), 1);
            }
            window.recalculateMath();
            window.buildAncestryLists();
            window.processNextPendingRaceChoice();
        };
    }
};
